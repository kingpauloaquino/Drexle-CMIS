<?php

return [

    'domain' => env('MSG4wrdIO_DOMAIN', 'http://outbound.msg4wrd.io'),

    'token' => env('MSG4wrdIO_TOKEN', 'YOUR-TOKEN-HERE'),

];
