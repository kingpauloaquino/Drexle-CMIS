<?php $__env->startSection('content'); ?>
<center>
    <table border="0" style="width: 730px;">
        <tr>
            <td class="text-center">
                <h3 style="margin: 0; padding: 0;">
                    BARANGAY CERTIFICATION
                </h3>
                <p> (First Time Jobseekers Assistance Act-RA11261)</p>
            </td>
        </tr>
        <tr>
            <td style="padding: 10px;">
                <p style="padding: 0; margin: 0;">
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;This is to certify that <b><?php echo e($data["title"]); ?> <?php echo e($data["fullname"]); ?></b>, <b><?php echo e($data["age"]); ?></b> years old, a resident of <b><?php echo e($data["address"]); ?></b>, East Bajac – Bajac, Olongapo City is a qualified availed of <b>RA 11261</b> or the <b>First Time Jobseekers Act of 2019</b>.
                </p>
            </td>
        </tr>
        <tr>
            <td style="padding: 10px;">
                <p style="padding: 0; margin: 0;">
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;I further certify that the holder/bearer was informed of his/her rights, including the duties and responsibilities accorded by <b>RA 11261</b> through the <b>Oath of Undertaking</b> he/she has assigned and executed in the presence of our Barangay Official.
                </p>
            </td>
        </tr>
        <tr>
            <td>
                <p style="padding: 0 0 0 50px; margin: 0;">
                    Signed this <b><?php echo e($data["day"]); ?></b> day of <b><?php echo e($data["month"]); ?></b>, <b><?php echo e($data["year"]); ?></b> in the City/Municipality of Barangay East Bajac - Bajac.
                </p>
            </td>
        </tr>
        <tr>
            <td class="text-center">
                <p style="padding: 0; margin: 0;">
                    This certification is valid only for one (1) year from the issuance.
                </p>
            </td>
        </tr>
    </table>
</center>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.cert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\king\Documents\GitHub\Drexle-CMIS\resources\views/pages/certificate/brgy_firstjobseeker.blade.php ENDPATH**/ ?>