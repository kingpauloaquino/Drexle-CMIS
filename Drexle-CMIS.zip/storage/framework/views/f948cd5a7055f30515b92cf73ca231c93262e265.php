<?php $__env->startSection('content'); ?>
<main>
    <header class="page-header page-header-dark bg-gradient-primary-to-secondary pb-10">
        <div class="container">
            <div class="page-header-content">
                <div class="row align-items-center justify-content-between">
                    <div class="col-auto">
                        <h1 class="page-header-title">
                            SMS Message History
                        </h1>
                        <div class="page-header-subtitle"></div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- Main page content-->
    <div class="container mt-4">
        <div class="card mb-4">
            <div class="card-body">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Subject</th>
                            <th>To</th>
                            <th>Message</th>
                            <th>Status</th>
                            <th>Date Added</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $count = 1; ?>
                        <?php for($i = 0; $i < COUNT($data); $i++): ?> <tr>
                            <td><?php echo e($count); ?></td>
                            <td><?php echo e($data[$i]["subject"]); ?></td>
                            <td><?php echo e($data[$i]["mobile"]); ?></td>
                            <td><?php echo e($data[$i]["message"]); ?></td>
                            <td>
                                <?php if($data[$i]["status"] == 1): ?>
                                    Sent
                                <?php elseif($data[$i]["status"] == 2): ?>
                                    Failed
                                <?php else: ?>
                                    Pending
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($data[$i]["created_at"]); ?></td>
                            </tr>
                            <?php $count++; ?>
                            <?php endfor; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</main>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\king\Documents\GitHub\Drexle-CMIS\resources\views/pages/sms/view.blade.php ENDPATH**/ ?>