<!DOCTYPE html>
<html>

<head>
    <title>KPAEngine v1</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: courier, arial, helvetica;
            font-size: 1.2em;
            display: flex;
            justify-content: center;
            text-align: center;
            align-items: center;
            width: 100%;
            height: 100vh;
        }

        h3 {
            margin: 0;
            padding: 0;
        }
    </style>
</head>

<body>
    <div>
        <img src='https://msg4wrd.io/images/Infinity211px.gif' alt='It' s working...' />
        <h3>Server is running!</h3>
    </div>
</body>

</html>
<?php /**PATH C:\Users\king\Documents\GitHub\Drexle-CMIS\vendor\kpawork\msg4wrd-io\src/views/status.blade.php ENDPATH**/ ?>